const express = require('express')
const app = express();
const path = require('path');
const router = express.Router();
var http= require("http").Server(app);
var io = require('socket.io')(http);
app.set('view engine', 'ejs');

app.get('/',function(req,res){	
  res.render('namespace');
});
io.on('connection',function(socket){
 	console.log('someone connected');

 	socket.on('first',function(da){
 		console.log(da);
 	});

 	var aaa='abcd-abcd';
 	var nsp = io.of('/'+aaa);
	nsp.on('connection', function(socket) {
	   console.log('namespace');
	   nsp.emit('hi', 'Hello everyone!');
	});
});



http.listen(2000, function() {
   console.log('listening on *:2000');
});