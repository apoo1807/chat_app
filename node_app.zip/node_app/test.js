const express = require('express')
const app = express();
const path = require('path');
const router = express.Router();
var http= require("http").Server(app);
var io = require('socket.io')(http);
var session = require('express-session');
var flash = require('req-flash');
const valid = require('node-input-validator');
var myParser = require("body-parser");
app.use(myParser.urlencoded({extended : true}));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({ cookie: { maxAge: 60000 }, 
                  secret: 'djhxcvxfgshajfgjhgsjhfgsakjeauytsdfy',
                  resave: false, 
                  saveUninitialized: true}
                 )
);
app.use(flash());
app.use(function(req, res, next){
  res.locals.messages = req.flash();
  next();
});

// mysql setup

const mysql = require('mysql');
var md5 = require('md5');
const pool = mysql.createPool({
    connectionLimit : 100, //important
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'node_app',
    debug    :  false
});

//index router

app.get('/',function(req,res){	
  res.render('home',{messages:req.flash('messages')});
});

//register router

app.post('/register',function(req,res){	
  let validator = new valid( req.body, {
  		name:'required',
        email:'required|email',
        password: 'required|minLength:8'
    });
 
    validator.check().then(function (matched) {
    	
        if (!matched) {   
            res.render('home',{rerrors:validator.errors,messages:'',rdata:req.body});           
        }else{
        	email=req.body.email;
        	pool.query("select * from users where email = ? ",[email],function(err,result){
        		if(result.length>0){
        			req.flash('messages', 'Email Already registered');
					  	//console.log(req.flash('messages', 'USER Created'));
					res.redirect('/');
        		}else{
        			let data = {name: req.body.name, email:req.body.email,password:md5(req.body.password)};
				  	let sql = "INSERT INTO users SET ?";
				  	let query = pool.query(sql, data,(err, results) => {
				   		if(err) throw err;
				    	req.flash('messages', 'USER Created');
					  	//console.log(req.flash('messages', 'USER Created'));
					  	res.redirect('/');
				  	});
		  	
        		}
        	});
        }
    });
});

//login router 
app.post('/login',function(req,res){	
  let validator = new valid( req.body, {
        email:'required',
        password: 'required'
    });  
    validator.check().then(function (matched) {    	
        if (!matched) {           
            res.render('home',{lerrors:validator.errors,messages:'',ldata:req.body});           
        }else{
        	email=req.body.email;
        	password=md5(req.body.password);
        	pool.query("SELECT * from users where email = ? and password = ?",[email,password],function (err, results){
		   		if(err) throw err;		   		
		    	if(results.length>0){		    		
			  		res.redirect('/users');
		    	}else{
		    		req.flash('messages', 'Invalid email and Password');			  		
			  		res.redirect('/');
		    	}
		  	});
        }
    });
});
// dashboard router
var obj={};
app.get('/users',function(req,res){	
	pool.query('SELECT * from user_info', function(err, rows){
	    if(err) {
		    console.log('error occurred during the connnection.');
		}
		else{			
			 obj = {data: rows};
			 res.render('users', {title: 'User List',row:obj});			
    }
	});
});


var username='';

app.get('/chat/:username', function(req, res) {
   res.render('chat');
   username=req.params.username;
});

io.on('connection',function(socket){
  socket.on('start',function(data){
    socket.emit('welcome','Hye ,'+username+' Welcome to Chat App');
  });

  socket.on('send_message',function(data){
    io.sockets.emit('message_recived',data);
  });

});


//app.use('/', router);
http.listen(2000, function() {
   console.log('listening on *:2000');
});