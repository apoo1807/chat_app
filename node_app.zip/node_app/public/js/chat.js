$(document).ready(function(){
	var month_name = function(dt){
		mlist = [ "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" ];
 		return mlist[dt.getMonth()];
	};
	
	function getChatroom(){
		var pageURL = $(location).attr("href");
        var index=pageURL.split("/");
        return index[index.length-1];
	}


	var sender=$('#sender').val();
	
	var socket = io();
	var name_socket=io('/'+sender);
	socket.emit("start");
	socket.on('welcome',function(data){
		$('#title_heading').html(data);
	});
	socket.emit('get_unread',sender);
	name_socket.on('rec_unread',function(data){
		$.each(data,function(i){
			var ns=data[i].sender_id;
			$('#unread_count'+ns).addClass('unread_count');
			var unrc=$('#unread_count'+ns).html();
			if(unrc=='' || unrc==null || isNaN(unrc)){
				unrc='0';
			}			
			$('#unread_count'+ns).html(parseInt(unrc)+1);
		});
	});
	//console.log(receiver);
	$('#message_form').on('submit',function(){
		var msg=$('#message').val();
		if(msg!=''){
			$('#message').val("");	
			var dt = new Date();				
			socket.emit("send_message",{
				message:msg,
				channel_room:getChatroom(),
				receiver_id:$('.active_chat').val(),
				sender_id:sender,
				/*
				dd:dt.getDate(),
				mon:month_name(dt),
				tt:dt.toLocaleString('en-US', { hour: 'numeric',minute:'numeric', hour12: true })
				*/
			});
		}
		return false;
	});
	name_socket.on('message_recived',function(data){
		//console.log(data);
		var content="";
		var croom=[data.sender_id,data.receiver_id].sort();
        var ccroom=croom[0].replace(/-/g,'')+croom[1].replace(/-/g,'');
        //console.log(ccroom+"/////"+getChatroom());
		if(ccroom==getChatroom()){
			if(data.sender_id!=sender){
				content="<div class='incoming_msg_img'>\
				 <img src='https://ptetutorials.com/images/user-profile.png' alt='laitkor'>\
				  </div>\
				  <div class='received_msg'>\
				  <div class='received_withd_msg'> \
				  <p>"+data.message+"</p>\
				  </div></div></div>";
				  socket.emit("message_read",data.message_id);
			}else{
				content="<div class='outgoing_msg'>\
	              <div class='sent_msg'>\
	                <p>"+data.message+"</p>\
	                 </div>\
	            </div>";
			}

			$('#msg_history').html($('#msg_history').html()+content);
			chat_scroll();

		}else{
			$('#unread_count'+data.sender_id).addClass('unread_count');
			var unrc=$('#unread_count'+data.sender_id).html();
			if(unrc=='' || unrc==null || isNaN(unrc)){
				unrc='0';
			}			
			$('#unread_count'+data.sender_id).html(parseInt(unrc)+1);
		}
	});	

var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.profile-pic').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
    

    $(".file-upload").on('change', function(){
        readURL(this);
    });
    
    $(".upload-button").on('click', function() {
       $(".file-upload").click();
    });
	
});
function chat_scroll(){
	chatWindow = document.getElementById('msg_history'); 
	var xH = chatWindow.scrollHeight+100; 
	chatWindow.scrollTo(0, xH);	
}
