const express = require('express')
const app = express();
const path = require('path');
const router = express.Router();
var myParser = require("body-parser");

var http= require("http").Server(app);
var io = require('socket.io')(http);

const mysql = require('mysql');
var md5 = require('md5');
const pool = mysql.createPool({
    connectionLimit : 100, //important
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'chat_app',
    debug    :  false
});


app.use(myParser.urlencoded({extended : true}));
app.set('view engine', 'ejs');
var username='';
app.use(express.static(path.join(__dirname, 'public')));
app.get('/chat/:username', function(req, res) {
   res.render('chat');
   username=req.params.username;
});

io.on('connection',function(socket){
	socket.on('start',function(data){
		//console.log(data);
		socket.emit('welcome','Hye ,'+username+' Welcome to Chat App');
	});

	socket.on('send_message',function(data){
		io.sockets.emit('message_recived',data);
	});

});

http.listen(2000, function() {
   console.log('listening on *:2000');
});