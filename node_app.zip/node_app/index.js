const express = require('express')
const app = express();
const path = require('path');
const router = express.Router();
var http= require("http").Server(app);
var io = require('socket.io')(http);
var session = require('express-session');
var flash = require('req-flash');
const valid = require('node-input-validator');
var myParser = require("body-parser");
app.use(myParser.urlencoded({extended : true}));
app.set('view engine', 'ejs');
const uuidv4 = require('uuid/v4');
var dformat = require('date-format');
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({ cookie: { maxAge: 6000000000000000 }, 
                  secret: 'djhxcvxfgshajfgjhgsjhfgsakjeauytsdfy',
                  resave: false, 
                  saveUninitialized: true}
                 )
);
app.use(flash());
app.use(function(req, res, next){
  res.locals.messages = req.flash();
  next();
});
var sess;
// mysql setup

const mysql = require('mysql');
var md5 = require('md5');
const pool = mysql.createPool({
    connectionLimit : 100, //important
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'node_app',
    debug    :  false
});

//index router

app.get('/',function(req,res){	
  res.render('home',{messages:req.flash('messages')});
});

//register router

app.post('/register',function(req,res){	
  let validator = new valid( req.body, {
  		name:'required',
        email:'required|email',
        password: 'required|minLength:8'
    });
 
    validator.check().then(function (matched) {
    	
        if (!matched) {   
            res.render('home',{rerrors:validator.errors,messages:'',rdata:req.body});           
        }else{
        	email=req.body.email;
        	pool.query("select * from users where email = ? ",[email],function(err,result){
        		if(result.length>0){
        			req.flash('messages', 'Email Already registered');
					  	//console.log(req.flash('messages', 'USER Created'));
					res.redirect('/');
        		}else{
        			let data = {
                name: req.body.name,
                email:req.body.email,
                password:md5(req.body.password),
                userid:uuidv4(),
              };
				  	  let sql = "INSERT INTO users SET ?";
				  	   let query = pool.query(sql, data,(err, results) => {
				   		   if(err) throw err;
				    	   req.flash('messages', 'USER Created');
					  	  //console.log(req.flash('messages', 'USER Created'));
					  	    res.redirect('/'); 
				  	   }); 
		  	 
        		} 
        	}); 
        } 
    }); 
});

//login router 
app.post('/login',function(req,res){	
  let validator = new valid( req.body, {
        email:'required',
        password: 'required'
    });  
    validator.check().then(function (matched) {    	
        if (!matched) {           
            res.render('home',{lerrors:validator.errors,messages:'',ldata:req.body});           
        }else{
        	email=req.body.email;
        	password=md5(req.body.password);
        	pool.query("SELECT * from users where email = ? and password = ?",[email,password],function (err, results){
		   		if(err) throw err;		   		
		    	if(results.length>0){		  
            sess=req.session;
            sess.email=email;
            sess.name=results[0].name;   
            sess.uid=results[0].userid;            
			  		res.redirect('/chat/');
		    	}else{
		    		req.flash('messages', 'Invalid email and Password');			  		
			  		res.redirect('/');
		    	}
		  	});
        }
    });
});

//logout router
app.get('/logout',(req,res) => {
    req.session.destroy((err) => {
        if(err) {
            return console.log(err);
        }
        //console.log(sess);
        res.redirect('/');
    });

});


// dashboard router
var obj={};
app.get('/users',function(req,res){	
	pool.query('SELECT * from user_info', function(err, rows){
	    if(err) {
		    console.log('error occurred during the connnection.');
		}
		else{
			//console.log(rows);
			obj = {data: rows};
			res.render('users', {title: 'User List',row:obj});			
        }
	});
});


var username='';
var userid='';

app.get('/chat/:username?/:chatroom?', function(req, res) {  
  sess=req.session;
  chatroom=req.params.chatroom;  
  user=req.params.username;
  userid=sess.uid;
  var rec_id='';
  if(typeof sess !=='undefined' && typeof sess.uid !=='undefined'){
    //console.log(chatroom);    
    var chat_msgs='';
    pool.query("select * from chats_messages where channel_room = ? ", [chatroom] , function(err,results){
      if(err) throw err;
      chat_msgs=results;
    });   
    pool.query("update chats_messages set read_status=1 where channel_room = ? and receiver_id = ? " , [chatroom,userid],function(err,result){
      if(err) throw err;

    });  

    pool.query('select * from users where userid!= ? ',[sess.uid],function(err,results){
      if(err) throw err;
        results.forEach(function(result,i){
          var data=[sess.uid,result.userid].sort();
          result.room=data[0].replace(/-/g,'')+data[1].replace(/-/g,'');
        });
        res.render('chat',{sender:sess.uid,users:results,chatroom:chatroom,msgs:chat_msgs,user:user});
        username=sess.name;        
    });
  }else{
    res.redirect('/');
  }
});

io.on('connection',function(socket){  
  var nss1='';
  socket.on('start',function(data){     
    socket.emit('welcome','Hye ,'+username+' Welcome to Chat App');
  });
  socket.on('get_unread',function(data){
    pool.query('select * from chats_messages where read_status=0 and receiver_id= ? ',[data],function(err,results){
      if(err) throw err;      
      //console.log(results);
      var nss1=io.of('/'+data); 
      nss1.emit('rec_unread',results);
    });
  });
  socket.on('send_message',function(data){    
    var nsr=io.of('/'+data.receiver_id); 
    nss1=io.of('/'+data.sender_id);  
    nsr.on('connection',function(){
       
    });     
    data.message_id=uuidv4();  
    pool.query('insert into chats_messages set ? ',data,function(err,results){
      if(err) throw err;      
    });
    nsr.emit('message_recived',data); 
    nss1.emit('message_recived',data);    
  });
  socket.on("message_read",function(data){
    pool.query("update chats_messages set read_status=1 where message_id = ? " , data,function(err,result){
      if(err) throw err;

    });
  });
});
http.listen(3000, '192.168.1.9',function() {
   console.log('listening on *:3000');
});
http.setTimeout(500000);